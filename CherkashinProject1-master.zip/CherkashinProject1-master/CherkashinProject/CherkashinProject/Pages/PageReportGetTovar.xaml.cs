﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CherkashinProject.Pages
{
    /// <summary>
    /// Interaction logic for PageReportGetTovar.xaml
    /// </summary>
    public partial class PageReportGetTovar : Page
    {
        public PageReportGetTovar()
        {
            InitializeComponent();
        }

        private void BtnReport_Click(object sender, RoutedEventArgs e)
        {
            var tovares = AppData.Context.GetTovara.ToList();



            var result = new StringBuilder();

            // Основные теги перед генерацией таблицы.
            result.Append("<html>");
            result.Append("<meta charset='utf-8'/>");
            result.Append("<body>");

            // Заголовок отчета.
            result.Append("<p align='center'> <b>Отчет по товаром</b> </p>");

            // Тег с параметрами таблицы.
            result.Append("<table width=100% border=1 bordercolor=#000 style='border-collapse:collapse;'>");

            // Настройка строк и столбцов внутри. tr - строка, td - столбец.
            result.Append("<tr>");
            // Необходимые заголовки таблицы.
            result.Append("<td align=center><b>Код</b></td>");
            result.Append("<td align=center><b>Товар</b></td>");
            result.Append("<td align=center><b>Склад</b></td>");
            result.Append("<td align=center><b>Количество</b></td>");
            result.Append("<td align=center><b>Цена</b></td>");
            result.Append("<td align=center><b>Менеджер</b></td>");
            result.Append("</tr>");

            // Генерация содержимого через цикл.
            foreach (var item in tovares)
            {
                // Настройка строк и столбцов внутри. tr - строка, td - столбец.
                result.Append("<tr>");
                // Обращение к переменной item и получение необходимого свойства в соответствии с заголовком.
                result.Append($"<td align=center>{item.GetId}</td>");
                result.Append($"<td align=center>{item.Tovares.TovarName}</td>");
                result.Append($"<td align=center>{item.Sklad.SkladName}</td>");
                result.Append($"<td align=center>{item.Count}</td>");
                result.Append($"<td align=center>{item.Price}</td>");
                result.Append($"<td align=center>{item.Users.Name}</td>");
                result.Append("</tr>");
            }

            // Закрытие основных тегов.
            result.Append("</table>");
            result.Append("</body>");
            result.Append("</html>");

            // Загрузка отчета в WebBrowser.
            Browser.NavigateToString(result.ToString());
        }

        private void Print_Click(object sender, RoutedEventArgs e)
        {
            var document = Browser.Document as IHTMLDocument2;
            document.execCommand("Print");
        }
    }
}
