﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CherkashinProject.Pages
{
    /// <summary>
    /// Interaction logic for PageReportChack.xaml
    /// </summary>
    public partial class PageReportChack : Page
    {
        public int id;
        public PageReportChack(int idTovar)
        {
            InitializeComponent();
            id = idTovar;
        }

        private void BtnReport_Click(object sender, RoutedEventArgs e)
        {
            var tovares = AppData.Context.PostTovara.ToList();

            tovares = tovares.Where(p => p.PostId == id).ToList();


            var result = new StringBuilder();

            // Основные теги перед генерацией таблицы.
            result.Append("<html>");
            result.Append("<meta charset='utf-8'/>");
            result.Append("<body>");


            foreach (var item in tovares)
            {
                // Заголовок отчета.
                result.Append("<p align='center'> <b>Счет фактура №"+ item.PostId + "</b> </p>");
                result.Append("<p align='left'> <b>Продавец: ООО Лайнкор</b></p>");
                result.Append("<p align='left'> <b>Адрес: Курск, ул. Победа, д. 10</b></p>");
                result.Append("<p align='left'> <b>ИНН: 245812574587</b></p>");
                result.Append("<p align='left'> <b>Дата продажи: " + item.DateOfPost + " </b></p>");
                result.Append("<p align='left'> <b>Покупатель: " + item.Kontragent.KontragentName + " </b></p>");

                // Тег с параметрами таблицы.
                result.Append("<table width=100% border=1 bordercolor=#000 style='border-collapse:collapse;'>");

                // Настройка строк и столбцов внутри. tr - строка, td - столбец.
                result.Append("<tr>");
                // Необходимые заголовки таблицы.
                result.Append("<td align=center><b>Код</b></td>");
                result.Append("<td align=center><b>Товар</b></td>");
                result.Append("<td align=center><b>Количество</b></td>");
                result.Append("<td align=center><b>Цена</b></td>");
                result.Append("<td align=center><b>Контрагент</b></td>");
                result.Append("<td align=center><b>Продавец</b></td>");
                result.Append("</tr>");

                // Генерация содержимого через цикл.

                // Настройка строк и столбцов внутри. tr - строка, td - столбец.
                result.Append("<tr>");
                // Обращение к переменной item и получение необходимого свойства в соответствии с заголовком.
                result.Append($"<td align=center>{item.PostId}</td>");
                result.Append($"<td align=center>{item.Tovares.TovarName}</td>");
                result.Append($"<td align=center>{item.Count}</td>");
                result.Append($"<td align=center>{item.Price}</td>");
                result.Append($"<td align=center>{item.Kontragent.KontragentName}</td>");
                result.Append($"<td align=center>{item.Users.Name}</td>");
                result.Append("</tr>");



            }
            // Закрытие основных тегов.

            result.Append("</table>");
            result.Append("<p align='left'> <b>Подпись директора______________________________   Подпись покупателя______________________________</b></p>");
            result.Append("<p align='left'> <b>М.П.</b></p>");
            result.Append("</body>");
            result.Append("</html>");

            // Загрузка отчета в WebBrowser.
            Browser.NavigateToString(result.ToString());
        }

        private void Print_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
